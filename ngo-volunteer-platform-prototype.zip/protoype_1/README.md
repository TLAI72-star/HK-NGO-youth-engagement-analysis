# Youth Connection Platform Prototype

This folder now includes a self-contained frontend prototype for the youth connection platform.

## How to use it

1. Open `index.html` in a web browser.
2. Use the account switcher in the top-right corner to swap between:
   - `Alex_Wong (YOUTH)`
   - `Sarah_Admin (STAFF)`

## Included flows

- Anonymous youth posting
- Support-request filtering
- "I'll join you!" support action
- Activity RSVP with point rewards
- Reward redemption
- Staff moderation with hide/unhide
- Staff activity creation
- Staff user overview

## Why it is built this way

`node` and `npm` are not installed in the current environment, so this version is built with plain HTML, CSS, and JavaScript so it works immediately without extra setup.
