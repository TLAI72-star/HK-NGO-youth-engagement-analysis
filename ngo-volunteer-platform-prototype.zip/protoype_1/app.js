const copy = {
  en: {
    appTitle: "Volunteer Coordination Platform",
    account: "Demo Account Switcher",
    lang: "Language",
    roles: { YOUTH_VOLUNTEER: "Youth Volunteer", CENTRE_STAFF: "Centre Staff", PARTNER: "Organization / Individual" },
    hero: {
      YOUTH_VOLUNTEER: ["Youth Volunteer Dashboard", "Welcome back", "Browse centre-led volunteer work, review approved partner requests, and join meaningful service opportunities."],
      CENTRE_STAFF: ["Centre Staff Dashboard", "Hello", "Approve and edit incoming requests, then publish them as visible collaboration posts for youth volunteers."],
      PARTNER: ["Partner Portal", "Submit your request", "Request venue booking or youth volunteer collaboration through the centre's shared platform."],
    },
    labels: {
      joinedActivities: "Joined activities", openCalls: "Open volunteer calls", yourPoints: "Your points",
      publishedActivities: "Published activities", pendingRequests: "Pending requests", youthVolunteers: "Youth volunteers",
      yourRequests: "Your requests", centreActivities: "Centre activities", volunteerActivities: "Volunteer Activities",
      volunteerHint: "Centre staff release volunteer opportunities here. The seeded demo items are Activity 1 and Activity 2.",
      allActivities: "All Activities", myActivities: "My Activities", noActivities: "You have not joined any activities yet.",
      partnerPosts: "Approved Partner Posts", partnerHint: "Approved requests stay visible here as posts. Youth can review them, and volunteer requests can be joined directly.",
      noPosts: "No approved partner posts are open right now.", volunteerProfile: "Volunteer Profile", profileHint: "Your current profile summary for staff matching.",
      rewards: "Gift Exchange", rewardsHint: "Use your points to redeem small gifts and treats.", redeem: "Redeem", pointsSuffix: "pts",
      interests: "Interests", needs: "Accessibility needs", none: "None listed", releaseActivity: "Release Volunteer Activity",
      releaseHint: "Create volunteer work and publish it instantly to the youth dashboard.", title: "Title", description: "Description",
      date: "Date", points: "Points Reward", capacity: "Volunteer Capacity", publishActivity: "Publish Activity",
      incoming: "Incoming External Requests", incomingHint: "Pending requests from organizations or individuals waiting for staff review.", noPending: "No pending requests right now.",
      board: "Request Board", boardHint: "All requests remain visible here after approval so staff can continue reviewing and editing the information.", noRequests: "No requests available right now.",
      edit: "Edit Request", editHint: "Update the selected request and save the new details.", save: "Save Request Changes", selectRequest: "Select a request from the board to edit its details.",
      youthOverview: "Youth Volunteer Overview", youthOverviewHint: "Staff-only summary of volunteers and participation.", liveList: "Live Volunteer Activity List", liveListHint: "These are the opportunities currently visible to youth volunteers.",
      booking: "Place Booking Request", bookingHint: "Request to use centre space for your programme or event.", volunteerReq: "Volunteer Collaboration Request", volunteerReqHint: "Ask the centre to coordinate youth volunteers for a joint programme.",
      orgName: "Organization / Individual", reqTitle: "Request Title", reqDate: "Requested Date", volunteersNeeded: "Volunteers Needed", sendBooking: "Send Booking Request", sendVolunteer: "Send Volunteer Request",
      mySubmitted: "My Submitted Requests", mySubmittedHint: "Track whether staff have approved your booking or collaboration request.", noSubmitted: "No requests submitted yet.",
      placeBooking: "Place Booking", volunteerCollab: "Volunteer Collaboration", requested: "Requested", requester: "Requester", assigned: "Assigned",
      bookingNotice: "Venue booking notice", volunteerWork: "Volunteer work", spotsLeft: "spots left", centreLed: "Centre-led", partnerCollab: "Partner collaboration", createdBy: "Created by centre staff",
      joinedText: "joined", joinActivity: "Join Activity", joined: "Joined", full: "Full", approve: "Approve", decline: "Decline", publishToYouth: "Publish to Youth", volunteerFor: "Volunteer for this request",
      viewOnly: "Visible to youth as an info post",
    },
    status: { PENDING: "Pending", APPROVED: "Approved", DECLINED: "Declined" },
    placeholders: { bookingTitle: "Room booking for workshop", bookingDesc: "Share the space, setup, and purpose...", volunteerTitle: "Need helpers for community fair", volunteerDesc: "What support do you need from volunteers?", activityTitle: "Activity 3", activityDesc: "Describe the volunteer work..." },
    flash: { required: "Complete all required fields before saving.", bookingSent: "Your place booking request has been sent to centre staff.", volunteerSent: "Your volunteer collaboration request has been sent to centre staff.", requestSaved: "Request details updated successfully.", requestApproved: "Request approved and published successfully.", requestDeclined: "Request declined.", requestPublished: "The request is now visible on the youth dashboard.", joinedRequest: "You joined this collaboration request and received 20 points.", activityCreated: "Volunteer activity published successfully.", rewardError: "You do not have enough points for this gift.", rewardSuccess: "Gift redeemed successfully:" },
  },
  zh: {
    appTitle: "義工協作平台",
    account: "示範帳戶切換",
    lang: "語言",
    roles: { YOUTH_VOLUNTEER: "青年義工", CENTRE_STAFF: "中心職員", PARTNER: "機構 / 個人" },
    hero: {
      YOUTH_VOLUNTEER: ["青年義工主頁", "歡迎回來", "瀏覽中心發布的義工活動、查看已批准的合作貼文，並加入有意義的服務機會。"],
      CENTRE_STAFF: ["中心職員主頁", "你好", "審批及編輯外部申請，並把已批准的需求發布成青年可見的合作貼文。"],
      PARTNER: ["合作夥伴入口", "提交你的申請", "透過平台向中心申請場地預約，或申請青年義工合作支援。"],
    },
    labels: {
      joinedActivities: "已參加活動", openCalls: "開放義工需求", yourPoints: "你的積分",
      publishedActivities: "已發布活動", pendingRequests: "待處理申請", youthVolunteers: "青年義工人數",
      yourRequests: "你的申請", centreActivities: "中心活動", volunteerActivities: "義工活動",
      volunteerHint: "中心職員會在此發布義工機會。示範預設活動為 Activity 1 及 Activity 2。",
      allActivities: "所有活動", myActivities: "我的活動", noActivities: "你暫時未參加任何活動。",
      partnerPosts: "已批准合作貼文", partnerHint: "已批准申請會保留在這裡作為貼文。青年可查看內容，而義工需求可直接加入。",
      noPosts: "目前沒有已批准的合作貼文。", volunteerProfile: "義工檔案", profileHint: "供職員配對的個人資料摘要。",
      rewards: "禮品換領", rewardsHint: "使用積分換領小禮物和飲品。", redeem: "換領", pointsSuffix: "分",
      interests: "興趣", needs: "無障礙需要", none: "沒有資料", releaseActivity: "發布義工活動",
      releaseHint: "建立義工工作並即時發布到青年主頁。", title: "標題", description: "描述",
      date: "日期", points: "積分獎勵", capacity: "名額", publishActivity: "發布活動",
      incoming: "待審批外部申請", incomingHint: "來自機構或個人的待處理申請，等待職員審批。", noPending: "目前沒有待處理申請。",
      board: "申請總覽", boardHint: "所有申請在批准後仍會保留在此，方便職員繼續查看及修改資料。", noRequests: "目前沒有申請。",
      edit: "編輯申請", editHint: "修改所選申請並儲存最新資料。", save: "儲存申請更改", selectRequest: "請先在總覽中選擇一個申請作編輯。",
      youthOverview: "青年義工總覽", youthOverviewHint: "職員專用的義工與參與情況摘要。", liveList: "即時義工活動列表", liveListHint: "這些是青年義工目前可見的活動。",
      booking: "場地預約申請", bookingHint: "申請使用中心場地舉辦你的活動或服務。", volunteerReq: "義工合作申請", volunteerReqHint: "向中心申請青年義工參與聯合活動。",
      orgName: "機構 / 個人名稱", reqTitle: "申請標題", reqDate: "申請日期", volunteersNeeded: "所需義工人數", sendBooking: "送出場地申請", sendVolunteer: "送出義工申請",
      mySubmitted: "我的申請紀錄", mySubmittedHint: "追蹤場地或義工合作申請的審批狀態。", noSubmitted: "你尚未提交任何申請。",
      placeBooking: "場地預約", volunteerCollab: "義工合作", requested: "申請時間", requester: "申請者", assigned: "已配對",
      bookingNotice: "場地預約通知", volunteerWork: "義工工作", spotsLeft: "個剩餘名額", centreLed: "中心發布", partnerCollab: "合作夥伴協作", createdBy: "由中心職員建立",
      joinedText: "已參加", joinActivity: "加入活動", joined: "已加入", full: "額滿", approve: "批准", decline: "拒絕", publishToYouth: "發布到青年頁面", volunteerFor: "登記支援此申請",
      viewOnly: "已作資訊貼文顯示",
    },
    status: { PENDING: "待處理", APPROVED: "已批准", DECLINED: "已拒絕" },
    placeholders: { bookingTitle: "工作坊場地預約", bookingDesc: "請說明用途、場地安排及需要...", volunteerTitle: "社區嘉年華需要義工", volunteerDesc: "請說明義工需要支援的內容。", activityTitle: "Activity 3", activityDesc: "請描述義工工作的內容..." },
    flash: { required: "請先填妥所有必填欄位。", bookingSent: "場地預約申請已送交中心職員。", volunteerSent: "義工合作申請已送交中心職員。", requestSaved: "申請資料已成功更新。", requestApproved: "申請已批准並發布。", requestDeclined: "申請已被拒絕。", requestPublished: "此申請現已顯示於青年主頁。", joinedRequest: "你已加入此合作申請，並獲得 20 分。", activityCreated: "義工活動已成功發布。", rewardError: "你的積分不足，未能換領此禮品。", rewardSuccess: "成功換領禮品：" },
  },
};

const state = {
  language: "en",
  users: [
    { id: "u_001", role: "YOUTH_VOLUNTEER", username: "Alex_Wong", alias: "BlueSky99", interests: ["Board Games", "Music", "Community Service"], points: 120, accessibilityNeeds: ["Quiet spaces"] },
    { id: "s_001", role: "CENTRE_STAFF", username: "Sarah_Admin", alias: "Staff_Sarah", interests: ["Community Building", "Volunteer Coordination"], points: 0, accessibilityNeeds: [] },
    { id: "o_001", role: "PARTNER", username: "HelpingHands_Org", alias: "HelpingHands", interests: ["Community Outreach", "Volunteer Programs"], points: 0, accessibilityNeeds: [] },
  ],
  activities: [
    { id: "a_001", title: "Activity 1", description: "Community centre welcome desk support and visitor guidance.", date: "2026-04-02T14:00:00", pointsReward: 30, capacity: 6, attendeeIds: ["u_001"], createdBy: "s_001", partnerRequestId: null },
    { id: "a_002", title: "Activity 2", description: "Weekend neighbourhood clean-up with light coordination duties.", date: "2026-04-06T10:30:00", pointsReward: 40, capacity: 8, attendeeIds: [], createdBy: "s_001", partnerRequestId: null },
  ],
  rewards: [
    { id: "gift_001", name: "Bubble Milk Tea Ticket", cost: 100 },
    { id: "gift_002", name: "Snack Coupon", cost: 80 },
    { id: "gift_003", name: "Stationery Pack", cost: 60 },
  ],
  requests: [
    { id: "req_001", requesterId: "o_001", requesterName: "Helping Hands Association", type: "PLACE_BOOKING", title: "Community Room Booking", description: "Requesting the multi-purpose room for a Saturday family support session.", requestedDate: "2026-04-10T15:00:00", status: "PENDING", volunteersNeeded: 0, assignedVolunteerIds: [], publishedToYouth: false },
    { id: "req_002", requesterId: "o_001", requesterName: "Helping Hands Association", type: "VOLUNTEER_SUPPORT", title: "Event Support Team", description: "Need volunteers to help with registration and wayfinding during a joint outreach day.", requestedDate: "2026-04-12T09:30:00", status: "APPROVED", volunteersNeeded: 3, assignedVolunteerIds: [], publishedToYouth: true },
  ],
  currentUserId: "u_001",
  activityFilter: "ALL",
  staffActivityForm: { title: "", description: "", date: "", pointsReward: "25", capacity: "6" },
  staffEditRequestId: "",
  staffRequestForm: { requesterName: "", title: "", description: "", requestedDate: "", volunteersNeeded: "1" },
  partnerForms: {
    booking: { requesterName: "Helping Hands Association", title: "", description: "", requestedDate: "" },
    volunteer: { requesterName: "Helping Hands Association", title: "", description: "", requestedDate: "", volunteersNeeded: "3" },
  },
  flash: null,
};

const accountSwitcher = document.getElementById("accountSwitcher");
const languageSwitcher = document.getElementById("languageSwitcher");
const appRoot = document.getElementById("app");
const topbarTitle = document.getElementById("appTitle");
const accountLabel = document.getElementById("accountSwitcherLabel");
const languageLabel = document.getElementById("languageLabel");

const txt = (path) => path.split(".").reduce((acc, key) => acc[key], copy[state.language]);
const roleName = (role) => txt("roles")[role];
const currentUser = () => state.users.find((u) => u.id === state.currentUserId);
const userById = (id) => state.users.find((u) => u.id === id);
const fmtDate = (value) => new Intl.DateTimeFormat(state.language === "zh" ? "zh-HK" : "en-HK", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }).format(new Date(value));
const statusName = (status) => txt("status")[status];
const typeName = (type) => (type === "PLACE_BOOKING" ? txt("labels.placeBooking") : txt("labels.volunteerCollab"));

function setFlash(type, message) {
  state.flash = { type, message };
  render();
  clearTimeout(setFlash.timer);
  setFlash.timer = setTimeout(() => { state.flash = null; render(); }, 2600);
}

function renderTopbar() {
  topbarTitle.textContent = txt("appTitle");
  accountLabel.textContent = txt("account");
  languageLabel.textContent = txt("lang");
  accountSwitcher.innerHTML = state.users.map((u) => `<option value="${u.id}" ${u.id === state.currentUserId ? "selected" : ""}>${u.username} (${roleName(u.role)})</option>`).join("");
  languageSwitcher.innerHTML = `<option value="en" ${state.language === "en" ? "selected" : ""}>English</option><option value="zh" ${state.language === "zh" ? "selected" : ""}>中文</option>`;
}

function flashHtml() { return state.flash ? `<div class="status-banner ${state.flash.type}">${state.flash.message}</div>` : ""; }

function hero() {
  const u = currentUser();
  const hero = txt("hero")[u.role];
  const pending = state.requests.filter((r) => r.status === "PENDING").length;
  const calls = state.requests.filter((r) => r.status === "APPROVED" && r.publishedToYouth && r.type === "VOLUNTEER_SUPPORT").length;
  const stats = u.role === "YOUTH_VOLUNTEER"
    ? [[txt("labels.joinedActivities"), state.activities.filter((a) => a.attendeeIds.includes(u.id)).length], [txt("labels.openCalls"), calls], [txt("labels.yourPoints"), u.points]]
    : u.role === "CENTRE_STAFF"
    ? [[txt("labels.publishedActivities"), state.activities.length], [txt("labels.pendingRequests"), pending], [txt("labels.youthVolunteers"), state.users.filter((x) => x.role === "YOUTH_VOLUNTEER").length]]
    : [[txt("labels.yourRequests"), state.requests.filter((r) => r.requesterId === u.id).length], [txt("labels.openCalls"), calls], [txt("labels.centreActivities"), state.activities.length]];
  return `<section class="hero-card"><div class="hero-copy"><p class="eyebrow">${hero[0]}</p><h2>${hero[1]}, ${u.alias}</h2><p>${hero[2]}</p></div><div class="hero-stats">${stats.map((s) => `<div class="stat-pill"><span>${s[0]}</span><strong>${s[1]}</strong></div>`).join("")}</div></section>`;
}

function activityCard(a, staffView) {
  const u = currentUser();
  const joined = a.attendeeIds.includes(u.id);
  const remaining = Math.max(a.capacity - a.attendeeIds.length, 0);
  return `<article class="activity-card"><div class="post-top"><div><h3>${a.title}</h3><p class="section-subtitle">${fmtDate(a.date)}</p></div><span class="wallet-points">+${a.pointsReward} pts</span></div><p class="activity-description">${a.description}</p><div class="tag-row"><span class="tag">${txt("labels.volunteerWork")}</span><span class="tag">${remaining} ${txt("labels.spotsLeft")}</span><span class="tag">${a.partnerRequestId ? txt("labels.partnerCollab") : txt("labels.centreLed")}</span></div><div class="activity-meta" style="margin-top:16px;"><span class="meta-text">${a.attendeeIds.length}/${a.capacity} ${txt("labels.joinedText")}</span>${staffView ? `<span class="meta-text">${txt("labels.createdBy")}</span>` : `<button class="${joined || remaining === 0 ? "ghost-button" : "button"}" data-action="join-activity" data-activity-id="${a.id}" ${joined || remaining === 0 ? "disabled" : ""}>${joined ? txt("labels.joined") : remaining === 0 ? txt("labels.full") : txt("labels.joinActivity")}</button>`}</div></article>`;
}

function requestCard(r, opts = {}) {
  const u = currentUser();
  const assigned = r.assignedVolunteerIds.map((id) => userById(id)).filter(Boolean).map((x) => x.username).join(", ");
  const canVolunteer = opts.youth && r.type === "VOLUNTEER_SUPPORT" && r.status === "APPROVED" && r.publishedToYouth && !r.assignedVolunteerIds.includes(u.id) && r.assignedVolunteerIds.length < r.volunteersNeeded;
  const canApprove = opts.staff && r.status === "PENDING";
  const canPublish = opts.board && r.status === "APPROVED" && !r.publishedToYouth;
  return `<article class="post-card ${state.staffEditRequestId === r.id ? "selected-card" : ""}"><div class="post-top"><div><span class="alias">${userById(r.requesterId)?.alias || r.requesterName}</span><div class="post-type">${typeName(r.type)}</div></div><span class="status-chip status-${r.status.toLowerCase()}">${statusName(r.status)}</span></div><h3 style="margin-top:16px;">${r.title}</h3><p class="post-body">${r.description}</p><div class="tag-row"><span class="tag">${txt("labels.requested")}: ${fmtDate(r.requestedDate)}</span>${r.type === "VOLUNTEER_SUPPORT" ? `<span class="tag">${r.assignedVolunteerIds.length}/${r.volunteersNeeded} ${txt("labels.youthVolunteers").toLowerCase()}</span>` : `<span class="tag">${txt("labels.bookingNotice")}</span>`}</div><div class="post-footer" style="margin-top:16px;"><span class="meta-text">${txt("labels.requester")}: ${r.requesterName}</span>${assigned ? `<span class="meta-text">${txt("labels.assigned")}: ${assigned}</span>` : ""}</div><div class="button-row" style="margin-top:16px;">${opts.board || opts.staff ? `<button class="ghost-button" data-action="select-request" data-request-id="${r.id}">${txt("labels.edit")}</button>` : ""}${canVolunteer ? `<button class="button" data-action="join-request" data-request-id="${r.id}">${txt("labels.volunteerFor")}</button>` : ""}${opts.youth && r.type === "PLACE_BOOKING" && r.status === "APPROVED" ? `<span class="meta-text">${txt("labels.viewOnly")}</span>` : ""}${canApprove ? `<button class="button" data-action="approve-request" data-request-id="${r.id}">${txt("labels.approve")}</button><button class="danger-button" data-action="decline-request" data-request-id="${r.id}">${txt("labels.decline")}</button>` : ""}${canPublish ? `<button class="ghost-button active" data-action="publish-request" data-request-id="${r.id}">${txt("labels.publishToYouth")}</button>` : ""}</div></article>`;
}

function staffEditForm() {
  if (!state.staffEditRequestId) return `<div class="empty-state">${txt("labels.selectRequest")}</div>`;
  const r = state.requests.find((x) => x.id === state.staffEditRequestId);
  if (!r) return `<div class="empty-state">${txt("labels.selectRequest")}</div>`;
  return `<div class="form-grid"><div><label class="small-label" for="editRequesterName">${txt("labels.orgName")}</label><input id="editRequesterName" class="form-input" value="${state.staffRequestForm.requesterName}" /></div><div><label class="small-label" for="editRequestTitle">${txt("labels.reqTitle")}</label><input id="editRequestTitle" class="form-input" value="${state.staffRequestForm.title}" /></div><div><label class="small-label" for="editRequestDescription">${txt("labels.description")}</label><textarea id="editRequestDescription" class="form-textarea">${state.staffRequestForm.description}</textarea></div><div><label class="small-label" for="editRequestDate">${txt("labels.reqDate")}</label><input id="editRequestDate" type="datetime-local" class="form-input" value="${state.staffRequestForm.requestedDate}" /></div>${r.type === "VOLUNTEER_SUPPORT" ? `<div><label class="small-label" for="editRequestVolunteers">${txt("labels.volunteersNeeded")}</label><input id="editRequestVolunteers" type="number" min="1" class="form-input" value="${state.staffRequestForm.volunteersNeeded}" /></div>` : ""}<button class="button" data-action="save-request">${txt("labels.save")}</button></div>`;
}

function youthView() {
  const u = currentUser();
  const activities = state.activityFilter === "JOINED" ? state.activities.filter((a) => a.attendeeIds.includes(u.id)) : state.activities;
  const posts = state.requests.filter((r) => r.status === "APPROVED" && r.publishedToYouth);
  return `${hero()}<section class="dashboard-grid"><div class="column"><div class="panel"><div class="panel-header"><div><h3>${txt("labels.volunteerActivities")}</h3><p class="section-subtitle">${txt("labels.volunteerHint")}</p></div></div>${flashHtml()}<div class="toggle-row" style="margin-bottom:18px;"><button class="${state.activityFilter === "ALL" ? "ghost-button active" : "ghost-button"}" data-action="set-activity-filter" data-filter="ALL">${txt("labels.allActivities")}</button><button class="${state.activityFilter === "JOINED" ? "ghost-button active" : "ghost-button"}" data-action="set-activity-filter" data-filter="JOINED">${txt("labels.myActivities")}</button></div><div class="activity-list">${activities.length ? activities.map((a) => activityCard(a, false)).join("") : `<div class="empty-state">${txt("labels.noActivities")}</div>`}</div></div></div><div class="column"><div class="panel"><div class="panel-header"><div><h3>${txt("labels.partnerPosts")}</h3><p class="section-subtitle">${txt("labels.partnerHint")}</p></div></div><div class="post-list">${posts.length ? posts.map((r) => requestCard(r, { youth: true })).join("") : `<div class="empty-state">${txt("labels.noPosts")}</div>`}</div></div><div class="panel"><div class="panel-header"><div><h3>${txt("labels.rewards")}</h3><p class="section-subtitle">${txt("labels.rewardsHint")}</p></div></div><div class="wallet-points">${u.points} ${txt("labels.pointsSuffix")}</div><div class="post-list" style="margin-top:16px;">${state.rewards.map((reward) => `<div class="muted-box"><div class="user-row"><div><strong>${reward.name}</strong><p class="section-subtitle">${reward.cost} ${txt("labels.pointsSuffix")}</p></div><button class="${u.points >= reward.cost ? "button" : "ghost-button"}" data-action="redeem-reward" data-reward-id="${reward.id}" ${u.points >= reward.cost ? "" : "disabled"}>${txt("labels.redeem")}</button></div></div>`).join("")}</div></div><div class="panel"><div class="panel-header"><div><h3>${txt("labels.volunteerProfile")}</h3><p class="section-subtitle">${txt("labels.profileHint")}</p></div></div><div class="wallet-points">${u.points} ${txt("labels.pointsSuffix")}</div><div class="muted-box" style="margin-top:14px;"><span class="small-label">${txt("labels.interests")}</span><div class="tag-row">${u.interests.map((i) => `<span class="tag">${i}</span>`).join("")}</div></div><div class="muted-box" style="margin-top:12px;"><span class="small-label">${txt("labels.needs")}</span><div class="tag-row">${u.accessibilityNeeds.length ? u.accessibilityNeeds.map((i) => `<span class="tag">${i}</span>`).join("") : `<span class="meta-text">${txt("labels.none")}</span>`}</div></div></div></div></section>`;
}

function staffView() {
  const youth = state.users.filter((u) => u.role === "YOUTH_VOLUNTEER");
  const pending = state.requests.filter((r) => r.status === "PENDING");
  return `${hero()}<section class="dashboard-grid"><div class="column"><div class="panel"><div class="panel-header"><div><h3>${txt("labels.releaseActivity")}</h3><p class="section-subtitle">${txt("labels.releaseHint")}</p></div></div>${flashHtml()}<div class="form-grid"><div><label class="small-label" for="activityTitle">${txt("labels.title")}</label><input id="activityTitle" class="form-input" placeholder="${txt("placeholders.activityTitle")}" value="${state.staffActivityForm.title}" /></div><div><label class="small-label" for="activityDescription">${txt("labels.description")}</label><textarea id="activityDescription" class="form-textarea" placeholder="${txt("placeholders.activityDesc")}">${state.staffActivityForm.description}</textarea></div><div><label class="small-label" for="activityDate">${txt("labels.date")}</label><input id="activityDate" type="datetime-local" class="form-input" value="${state.staffActivityForm.date}" /></div><div><label class="small-label" for="activityPoints">${txt("labels.points")}</label><input id="activityPoints" type="number" min="0" class="form-input" value="${state.staffActivityForm.pointsReward}" /></div><div><label class="small-label" for="activityCapacity">${txt("labels.capacity")}</label><input id="activityCapacity" type="number" min="1" class="form-input" value="${state.staffActivityForm.capacity}" /></div><button class="button" data-action="create-activity">${txt("labels.publishActivity")}</button></div></div><div class="panel"><div class="panel-header"><div><h3>${txt("labels.incoming")}</h3><p class="section-subtitle">${txt("labels.incomingHint")}</p></div></div><div class="post-list">${pending.length ? pending.map((r) => requestCard(r, { staff: true })).join("") : `<div class="empty-state">${txt("labels.noPending")}</div>`}</div></div><div class="panel"><div class="panel-header"><div><h3>${txt("labels.board")}</h3><p class="section-subtitle">${txt("labels.boardHint")}</p></div></div><div class="post-list">${state.requests.length ? state.requests.map((r) => requestCard(r, { board: true })).join("") : `<div class="empty-state">${txt("labels.noRequests")}</div>`}</div></div></div><div class="column"><div class="panel"><div class="panel-header"><div><h3>${txt("labels.edit")}</h3><p class="section-subtitle">${txt("labels.editHint")}</p></div></div>${staffEditForm()}</div><div class="panel"><div class="panel-header"><div><h3>${txt("labels.youthOverview")}</h3><p class="section-subtitle">${txt("labels.youthOverviewHint")}</p></div></div><div class="user-list">${youth.map((u) => `<article class="user-card"><div class="user-row"><div><h4>${u.username}</h4><p class="section-subtitle">Alias: ${u.alias}</p></div><span class="wallet-points">${u.points} pts</span></div><div class="tag-row" style="margin-top:14px;">${u.interests.map((i) => `<span class="tag">${i}</span>`).join("")}</div></article>`).join("")}</div></div><div class="panel"><div class="panel-header"><div><h3>${txt("labels.liveList")}</h3><p class="section-subtitle">${txt("labels.liveListHint")}</p></div></div><div class="activity-list">${state.activities.map((a) => activityCard(a, true)).join("")}</div></div></div></section>`;
}

function partnerView() {
  const mine = state.requests.filter((r) => r.requesterId === currentUser().id);
  return `${hero()}<section class="dashboard-grid"><div class="column"><div class="panel"><div class="panel-header"><div><h3>${txt("labels.booking")}</h3><p class="section-subtitle">${txt("labels.bookingHint")}</p></div></div>${flashHtml()}<div class="form-grid"><div><label class="small-label" for="bookingRequester">${txt("labels.orgName")}</label><input id="bookingRequester" class="form-input" value="${state.partnerForms.booking.requesterName}" /></div><div><label class="small-label" for="bookingTitle">${txt("labels.reqTitle")}</label><input id="bookingTitle" class="form-input" placeholder="${txt("placeholders.bookingTitle")}" value="${state.partnerForms.booking.title}" /></div><div><label class="small-label" for="bookingDescription">${txt("labels.description")}</label><textarea id="bookingDescription" class="form-textarea" placeholder="${txt("placeholders.bookingDesc")}">${state.partnerForms.booking.description}</textarea></div><div><label class="small-label" for="bookingDate">${txt("labels.reqDate")}</label><input id="bookingDate" type="datetime-local" class="form-input" value="${state.partnerForms.booking.requestedDate}" /></div><button class="button" data-action="submit-booking">${txt("labels.sendBooking")}</button></div></div><div class="panel"><div class="panel-header"><div><h3>${txt("labels.volunteerReq")}</h3><p class="section-subtitle">${txt("labels.volunteerReqHint")}</p></div></div><div class="form-grid"><div><label class="small-label" for="volunteerRequester">${txt("labels.orgName")}</label><input id="volunteerRequester" class="form-input" value="${state.partnerForms.volunteer.requesterName}" /></div><div><label class="small-label" for="volunteerTitle">${txt("labels.reqTitle")}</label><input id="volunteerTitle" class="form-input" placeholder="${txt("placeholders.volunteerTitle")}" value="${state.partnerForms.volunteer.title}" /></div><div><label class="small-label" for="volunteerDescription">${txt("labels.description")}</label><textarea id="volunteerDescription" class="form-textarea" placeholder="${txt("placeholders.volunteerDesc")}">${state.partnerForms.volunteer.description}</textarea></div><div><label class="small-label" for="volunteerDate">${txt("labels.reqDate")}</label><input id="volunteerDate" type="datetime-local" class="form-input" value="${state.partnerForms.volunteer.requestedDate}" /></div><div><label class="small-label" for="volunteerNeeded">${txt("labels.volunteersNeeded")}</label><input id="volunteerNeeded" type="number" min="1" class="form-input" value="${state.partnerForms.volunteer.volunteersNeeded}" /></div><button class="button" data-action="submit-volunteer-request">${txt("labels.sendVolunteer")}</button></div></div></div><div class="column"><div class="panel"><div class="panel-header"><div><h3>${txt("labels.mySubmitted")}</h3><p class="section-subtitle">${txt("labels.mySubmittedHint")}</p></div></div><div class="post-list">${mine.length ? mine.map((r) => requestCard(r)).join("") : `<div class="empty-state">${txt("labels.noSubmitted")}</div>`}</div></div></div></section>`;
}

function ensureLinkedActivity(r) {
  if (r.type !== "VOLUNTEER_SUPPORT") return;
  const existing = state.activities.find((a) => a.partnerRequestId === r.id);
  if (existing) {
    existing.title = r.title;
    existing.description = r.description;
    existing.date = r.requestedDate;
    existing.capacity = r.volunteersNeeded;
    existing.attendeeIds = [...r.assignedVolunteerIds];
    return;
  }
  state.activities.unshift({ id: `a_${Date.now()}`, title: r.title, description: r.description, date: r.requestedDate, pointsReward: 20, capacity: r.volunteersNeeded, attendeeIds: [...r.assignedVolunteerIds], createdBy: "s_001", partnerRequestId: r.id });
}

function selectRequest(id) {
  const r = state.requests.find((x) => x.id === id);
  if (!r) return;
  state.staffEditRequestId = id;
  state.staffRequestForm = { requesterName: r.requesterName, title: r.title, description: r.description, requestedDate: r.requestedDate, volunteersNeeded: String(r.volunteersNeeded || 1) };
  render();
}

function saveRequest() {
  const r = state.requests.find((x) => x.id === state.staffEditRequestId);
  if (!r) return setFlash("error", txt("labels.selectRequest"));
  const needed = Number(state.staffRequestForm.volunteersNeeded);
  if (!state.staffRequestForm.requesterName.trim() || !state.staffRequestForm.title.trim() || !state.staffRequestForm.description.trim() || !state.staffRequestForm.requestedDate || (r.type === "VOLUNTEER_SUPPORT" && (Number.isNaN(needed) || needed < 1))) return setFlash("error", txt("flash.required"));
  r.requesterName = state.staffRequestForm.requesterName.trim();
  r.title = state.staffRequestForm.title.trim();
  r.description = state.staffRequestForm.description.trim();
  r.requestedDate = state.staffRequestForm.requestedDate;
  if (r.type === "VOLUNTEER_SUPPORT") { r.volunteersNeeded = needed; ensureLinkedActivity(r); }
  setFlash("success", txt("flash.requestSaved"));
}

function joinActivity(id) {
  const a = state.activities.find((x) => x.id === id);
  const u = currentUser();
  if (!a || a.attendeeIds.includes(u.id) || a.attendeeIds.length >= a.capacity) return;
  a.attendeeIds.push(u.id);
  u.points += a.pointsReward;
  setFlash("success", `${txt("labels.joined")} ${a.title} +${a.pointsReward} pts`);
}

function joinRequest(id) {
  const r = state.requests.find((x) => x.id === id);
  const u = currentUser();
  if (!r || r.type !== "VOLUNTEER_SUPPORT" || r.status !== "APPROVED" || !r.publishedToYouth || r.assignedVolunteerIds.includes(u.id) || r.assignedVolunteerIds.length >= r.volunteersNeeded) return;
  r.assignedVolunteerIds.push(u.id);
  u.points += 20;
  ensureLinkedActivity(r);
  setFlash("success", txt("flash.joinedRequest"));
}

function redeemReward(id) {
  const reward = state.rewards.find((x) => x.id === id);
  const u = currentUser();
  if (!reward || u.role !== "YOUTH_VOLUNTEER") return;
  if (u.points < reward.cost) return setFlash("error", txt("flash.rewardError"));
  u.points -= reward.cost;
  setFlash("success", `${txt("flash.rewardSuccess")} ${reward.name}`);
}

function createActivity() {
  const f = state.staffActivityForm;
  const points = Number(f.pointsReward);
  const cap = Number(f.capacity);
  if (!f.title.trim() || !f.description.trim() || !f.date || Number.isNaN(points) || points < 0 || Number.isNaN(cap) || cap < 1) return setFlash("error", txt("flash.required"));
  state.activities.unshift({ id: `a_${Date.now()}`, title: f.title.trim(), description: f.description.trim(), date: f.date, pointsReward: points, capacity: cap, attendeeIds: [], createdBy: state.currentUserId, partnerRequestId: null });
  state.staffActivityForm = { title: "", description: "", date: "", pointsReward: "25", capacity: "6" };
  setFlash("success", txt("flash.activityCreated"));
}

function approveRequest(id) {
  const r = state.requests.find((x) => x.id === id);
  if (!r) return;
  r.status = "APPROVED";
  r.publishedToYouth = true;
  selectRequest(id);
  if (r.type === "VOLUNTEER_SUPPORT") ensureLinkedActivity(r);
  setFlash("success", txt("flash.requestApproved"));
}

function declineRequest(id) {
  const r = state.requests.find((x) => x.id === id);
  if (!r) return;
  r.status = "DECLINED";
  r.publishedToYouth = false;
  setFlash("success", txt("flash.requestDeclined"));
}

function publishRequest(id) {
  const r = state.requests.find((x) => x.id === id);
  if (!r || r.status !== "APPROVED") return;
  r.publishedToYouth = true;
  if (r.type === "VOLUNTEER_SUPPORT") ensureLinkedActivity(r);
  setFlash("success", txt("flash.requestPublished"));
}

function submitBooking() {
  const f = state.partnerForms.booking;
  if (!f.requesterName.trim() || !f.title.trim() || !f.description.trim() || !f.requestedDate) return setFlash("error", txt("flash.required"));
  state.requests.unshift({ id: `req_${Date.now()}`, requesterId: state.currentUserId, requesterName: f.requesterName.trim(), type: "PLACE_BOOKING", title: f.title.trim(), description: f.description.trim(), requestedDate: f.requestedDate, status: "PENDING", volunteersNeeded: 0, assignedVolunteerIds: [], publishedToYouth: false });
  state.partnerForms.booking.title = "";
  state.partnerForms.booking.description = "";
  state.partnerForms.booking.requestedDate = "";
  setFlash("success", txt("flash.bookingSent"));
}

function submitVolunteer() {
  const f = state.partnerForms.volunteer;
  const needed = Number(f.volunteersNeeded);
  if (!f.requesterName.trim() || !f.title.trim() || !f.description.trim() || !f.requestedDate || Number.isNaN(needed) || needed < 1) return setFlash("error", txt("flash.required"));
  state.requests.unshift({ id: `req_${Date.now()}`, requesterId: state.currentUserId, requesterName: f.requesterName.trim(), type: "VOLUNTEER_SUPPORT", title: f.title.trim(), description: f.description.trim(), requestedDate: f.requestedDate, status: "PENDING", volunteersNeeded: needed, assignedVolunteerIds: [], publishedToYouth: false });
  state.partnerForms.volunteer.title = "";
  state.partnerForms.volunteer.description = "";
  state.partnerForms.volunteer.requestedDate = "";
  state.partnerForms.volunteer.volunteersNeeded = "3";
  setFlash("success", txt("flash.volunteerSent"));
}

function render() {
  renderTopbar();
  const role = currentUser().role;
  appRoot.innerHTML = role === "YOUTH_VOLUNTEER" ? youthView() : role === "CENTRE_STAFF" ? staffView() : partnerView();
}

accountSwitcher.addEventListener("change", (e) => { state.currentUserId = e.target.value; state.flash = null; render(); });
languageSwitcher.addEventListener("change", (e) => { state.language = e.target.value; render(); });

document.addEventListener("input", (e) => {
  const map = {
    activityTitle: ["staffActivityForm", "title"], activityDescription: ["staffActivityForm", "description"], activityDate: ["staffActivityForm", "date"], activityPoints: ["staffActivityForm", "pointsReward"], activityCapacity: ["staffActivityForm", "capacity"],
    bookingRequester: ["partnerForms", "booking", "requesterName"], bookingTitle: ["partnerForms", "booking", "title"], bookingDescription: ["partnerForms", "booking", "description"], bookingDate: ["partnerForms", "booking", "requestedDate"],
    volunteerRequester: ["partnerForms", "volunteer", "requesterName"], volunteerTitle: ["partnerForms", "volunteer", "title"], volunteerDescription: ["partnerForms", "volunteer", "description"], volunteerDate: ["partnerForms", "volunteer", "requestedDate"], volunteerNeeded: ["partnerForms", "volunteer", "volunteersNeeded"],
    editRequesterName: ["staffRequestForm", "requesterName"], editRequestTitle: ["staffRequestForm", "title"], editRequestDescription: ["staffRequestForm", "description"], editRequestDate: ["staffRequestForm", "requestedDate"], editRequestVolunteers: ["staffRequestForm", "volunteersNeeded"],
  };
  const path = map[e.target.id];
  if (!path) return;
  let ref = state;
  for (let i = 0; i < path.length - 1; i += 1) ref = ref[path[i]];
  ref[path[path.length - 1]] = e.target.value;
});

document.addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-action]");
  if (!btn) return;
  const action = btn.dataset.action;
  if (action === "set-activity-filter") { state.activityFilter = btn.dataset.filter; return render(); }
  if (action === "join-activity") return joinActivity(btn.dataset.activityId);
  if (action === "join-request") return joinRequest(btn.dataset.requestId);
  if (action === "redeem-reward") return redeemReward(btn.dataset.rewardId);
  if (action === "create-activity") return createActivity();
  if (action === "approve-request") return approveRequest(btn.dataset.requestId);
  if (action === "decline-request") return declineRequest(btn.dataset.requestId);
  if (action === "publish-request") return publishRequest(btn.dataset.requestId);
  if (action === "submit-booking") return submitBooking();
  if (action === "submit-volunteer-request") return submitVolunteer();
  if (action === "select-request") return selectRequest(btn.dataset.requestId);
  if (action === "save-request") return saveRequest();
});

render();
